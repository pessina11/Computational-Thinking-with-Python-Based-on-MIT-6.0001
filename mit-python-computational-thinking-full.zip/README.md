# MIT - Computational Thinking in Python

Este repositório contém uma coleção de notebooks baseados no curso **"Introduction to Computer Science and Programming in Python" (6.0001)** do MIT.

## 📚 Conteúdo

Cada notebook aborda conceitos fundamentais de ciência da computação e programação com Python, incluindo:

- Variáveis, Tipos e Expressões
- Estruturas de Controle
- Funções e Escopo
- Recursão
- Algoritmos de Busca e Ordenação
- Simulações com Aleatoriedade
- Estimativas com Monte Carlo
- Programação Orientada a Objetos
- Testes e Depuração
- Projeto Final

## 🚀 Como usar

1. Clone ou baixe este repositório.
2. Instale os requisitos com `pip install -r requirements.txt`.
3. Abra os notebooks com Jupyter ou Google Colab.
4. Execute as células e explore os conceitos.

## 📌 Curso Original

Curso disponível em: [MIT OpenCourseWare - 6.0001](https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-0001-introduction-to-computer-science-and-programming-in-python-fall-2016/)

## 📄 Licença

Distribuído sob a licença MIT. Veja `LICENSE` para mais informações.
